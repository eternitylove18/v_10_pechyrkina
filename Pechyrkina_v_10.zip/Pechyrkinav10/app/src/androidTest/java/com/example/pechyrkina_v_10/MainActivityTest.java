package com.example.pechyrkina_v_10;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

    public void testOnClick() {
    }
}